import logo from './logo.svg';
import './App.css';
import Code from './Code'

function App() {
  return (
   <>
   <Code/>
   </>
  );
}

export default App;
